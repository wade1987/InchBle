/*********************************************************************************************************
*                                 Inch.c  ������
*
* �ļ���	: Inch.c
* �汾��	: V1.00
* ����	: ��ǿ
*             
*********************************************************************************************************/

#include "inch.h"
#include "oled.h"

/* ------------------------------------------------------------------------------------------------
 *                                      ���ļ�����ȫ�ֱ���
 * ------------------------------------------------------------------------------------------------
 */

//oled ��ʾ����
static t_uint_8 OledDisp[4][16];
static t_uint_8 OledDispBuf[4][16];
static t_uint_8 Str[10];

//�ϵ��ʱ��
static t_uint_32 SytmPwrOnTim = 0;

/*
*********************************************************************************************************
*                                           GUIUpdata()
*
* ����: ����ַ�����������Ļ����Ҫ���µ��ַ�
*
* ����: ��
*
* ��ע: ÿ����ѭ������ֻɨ����ʾһ���ַ�����performPeriodicTask �е���
*
*********************************************************************************************************
*/

void GUIUpdata(void)
{
	t_uint_8 RowCnt=0,ColCnt=0;

	for(RowCnt = 0 ; RowCnt < 4 ; RowCnt++)
	{
		for(ColCnt = 0 ;ColCnt < 16 ; ColCnt++)
		{
			if(OledDisp[RowCnt][ColCnt] != OledDispBuf[RowCnt][ColCnt])
			{
				OLED_ShowChar(ColCnt*8 , RowCnt*2 , OledDispBuf[RowCnt][ColCnt] , 16, 0);//��ɫ
				OledDisp[RowCnt][ColCnt] = OledDispBuf[RowCnt][ColCnt];
			}
		}
	}
}

/*
*********************************************************************************************************
*                                           GUIShowString()
*
* ����: ��ʾһ���ַ���
*
* ����: 
*
* ��ע: ��
*
*********************************************************************************************************
*/

void GUIShowString(t_uint_8 row , t_uint_8 col , t_uint_8 *Str , t_uint_8 StrSize)
{
	t_uint_8 i , j , size;

	//��ֹ���
	size = ((col + StrSize) > 16) ? (16 - col) : StrSize;
	//��ʾ�ַ���
	for(i = col , j = 0 ; i < col + size ; i++ , j++)
	{
		OledDispBuf[row][i] = Str[j];
	}
}

/*
*********************************************************************************************************
*                                           GUIInit()
*
* ����: ��ʼ��GUI ��صĶ���
*
* ����: ��
*
* ��ע: ��SimpleBLEPeripheral_Init �е���
*
*********************************************************************************************************
*/

void GUIInit(void)
{
	t_uint_8 i , j;

	OLED_Init();
	OLED_Clear();

	//ReverseFlag = 0;	//��ɫ��ʾ 

	
	for(i = 0 ; i < 4 ; i++)
	{
		for(j = 0 ; j < 16 ; j++) 
		{
			OledDisp[i][j] = 0x55;
			OledDispBuf[i][j] = ' '; 
		}
	}
	GUIShowString(0 , 0 , "L0:" , 3);GUIShowString(0 , 8 , "L1:" , 3);
	GUIShowString(1 , 0 , "L2:" , 3);GUIShowString(1 , 8 , "L3:" , 3);
	GUIShowString(2 , 0 , "L4:" , 3);GUIShowString(2 , 8 , "L5:" , 3);
	GUIShowString(3 , 0 , "L6:" , 3);GUIShowString(3 , 8 , "L9:" , 3);
	//GUIUpdata();
	
}

/*
*********************************************************************************************************
*                                           NumToStr()
*
* ����: uint16����ת�����ַ���
*
* ����: ��
*
* ��ע: ��
*
*********************************************************************************************************
*/

t_uint_8 * NumToStr(unsigned short Num)
{
	Str[0] = Num % 10000 / 1000 + '0'; //ǧλ
	Str[1] = Num % 1000 / 100 + '0'; //��λ
	Str[2]= Num % 100 / 10 + '0'; //ʮλ
	Str[3] = Num % 10 + '0'; //��λ
	
	return Str;
} 

/*
*********************************************************************************************************
*                                           LedRunning()
*
* ����: LEDָʾ������û��������
*
* ����: ��
*
* ��ע: ��
*********************************************************************************************************
*/

void LedRunning(void)
{
	static t_uint_8 flagg = 0;

	if(flagg)
	{
		LED_ON();
		flagg = 0;
	}
	else
	{
		LED_OFF();
		flagg = 1;
	}
  
}

/*
*********************************************************************************************************
*                                           InchMain()
*
* ����: ���Գߴ�
*
* ����: ��
*
* ��ע: ��performPeriodicTask �е���period = INCH_MAIN_TICK_TIME(ms) //100ms
*********************************************************************************************************
*/

void InchMain(void)
{

	static t_uint_16 TestBuf[8],i;

	LedRunning();

	for(i = 0 ; i < 8 ; i++)
	{
		TestBuf[i] += i;
		if(TestBuf[i] >= 9000) 
		TestBuf[i] = 0;
	}

	GUIShowString(0 , 3 , NumToStr(TestBuf[0]) , 4);GUIShowString(0 , 11 , NumToStr(TestBuf[1]) , 4);
	GUIShowString(1 , 3 , NumToStr(TestBuf[2]) , 4);GUIShowString(1 , 11 , NumToStr(TestBuf[3]) , 4);
	GUIShowString(2 , 3 , NumToStr(TestBuf[4]) , 4);GUIShowString(2 , 11 , NumToStr(TestBuf[5]) , 4);
	GUIShowString(3 , 3 , NumToStr(TestBuf[6]) , 4);GUIShowString(3 , 11 , NumToStr(TestBuf[7]) , 4);


	//���ϵ��ִ�еĳ���
	if(SytmPwrOnTim == 0)
	{
		IO_Init(); 
		LED_OFF();
		OLED_RST_Clr();
		SytmPwrOnTim++;
	}
	else if(SytmPwrOnTim < 6)
	{
		SytmPwrOnTim++;
	}
	else if(SytmPwrOnTim == 6)
	{
		LED_ON();
		OLED_RST_Set();
		SytmPwrOnTim++;
		GUIInit();
	}
	else
	{

	}  


	GUIUpdata();

}




