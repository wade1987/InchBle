/*********************************************************************************************************
*                                 Inch.h  ͷ�ļ�����
*
* �ļ���	: Inch.h
* �汾��	: V1.00
* ����	: ��ǿ
*             
*********************************************************************************************************/

#ifndef __INCH_H
#define __INCH_H 

#include<ioCC2540.h>
#include "oled.h"

#define	USE_HX711

/* ------------------------------------------------------------------------------------------------
 *                                      �ṹ�嶨��(��ֲMCUʱ�����)
 * ------------------------------------------------------------------------------------------------
 */

typedef signed   char   t_int_8;     //!< Signed 8 bit integer
typedef unsigned char   t_uint_8;    //!< Unsigned 8 bit integer

typedef signed   short  t_int_16;    //!< Signed 16 bit integer
typedef unsigned short  t_uint_16;   //!< Unsigned 16 bit integer

typedef signed   long   t_int_32;    //!< Signed 32 bit integer
typedef unsigned long   t_uint_32;   //!< Unsigned 32 bit integer 



/* ------------------------------------------------------------------------------------------------
 *                                      ����Ӳ����غ궨�壨��ֲӲ��ƽ̨ʱ�������
 * ------------------------------------------------------------------------------------------------
 */

//-----------------------------IO�ڶ���
//LED IO����
#define LED_INCH P1_0    
#define LED_ON() LED_INCH = 1
#define LED_OFF() LED_INCH = 0

//OLED IIC IO����
#define OLED_CLK_PIN			P0_6
#define	OLED_SCLK_Clr()			OLED_CLK_PIN = 0
#define	OLED_SCLK_Set()			OLED_CLK_PIN = 1

#define OLED_DAT_PIN			P0_5
#define	OLED_SDIN_Clr()			OLED_DAT_PIN = 0
#define	OLED_SDIN_Set()			OLED_DAT_PIN = 1

#define OLED_RST_PIN			P0_7
#define	OLED_RST_Clr()			OLED_RST_PIN = 0
#define	OLED_RST_Set()			OLED_RST_PIN = 1

//LDC IIC IO��������	 
#define SDA_IN()  {P1DIR &= 0xf7;P2INP = 0;P1INP &= 0xf7;}
#define SDA_OUT() {P1DIR |= 0x08;}

#define IIC_SCL    P1_2   //SCL
#define WRITE_SDA    P1_3 //д��SDA	 
#define READ_SDA   P1_3    //��ȡSDA 

//HX711 IO��������	 
#define ADDO_IN()  {P1DIR &= 0xf7;}
#define ADSK_OUT() {P1DIR |= 0x04;}

#define ADSK    P1_2   //SCL
#define ADDO   P1_3    //��ȡSDA


/*#define SDA_IN()  {P2DIR &= 0xfe;P2INP = 0;P2INP &= 0xfe;} 
#define SDA_OUT() {P2DIR |= 0x01;}

#define IIC_SCL    P2_1   //SCL
#define WRITE_SDA    P2_0 //д��SDA	 
#define READ_SDA   P2_0    //��ȡSDA */



//-----------------------------�꺯������

//P0_3,4,5,6,7 ���
//P1_0 ���
#define IO_Init(  )\
    do\
    {\
        P0SEL = 0;\
        P1SEL = 0;\
        P2SEL = 0;\
        P0DIR = 0xFC;\
        P1DIR = 0xFF;\
        P2DIR = 0x1F;\
        P0 = 0x03;\
        P1 = 0x0c;\
        P2 = 0;\
        P0DIR |= 0xf8;\
        P1DIR |= 0x01;\
    }   while( 1==0 )
    


/* ------------------------------------------------------------------------------------------------
 *                                      ����������غ궨��
 * ------------------------------------------------------------------------------------------------
 */

#define INCH_MAIN_TICK_TIME 100  // ms



/* ------------------------------------------------------------------------------------------------
 *                                      ������������
 * ------------------------------------------------------------------------------------------------
 */

void InchMain(void);


#endif

